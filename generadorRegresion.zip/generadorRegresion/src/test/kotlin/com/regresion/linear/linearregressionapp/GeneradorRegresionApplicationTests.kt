package com.regresion.linear.linearregressionapp

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class GeneradorRegresionApplicationTests {

    @Test
    fun contextLoads() {
    }

}
