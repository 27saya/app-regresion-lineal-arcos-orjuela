package com.regresion.linear.model

data class DataPoint(val x: Double, val y: Double)

