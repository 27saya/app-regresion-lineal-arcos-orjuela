rootProject.name = "regresion-lineal-app"


